var searchData=
[
  ['object_5fcreate',['object_create',['../object_8h.html#a6c55f8c2541966f6dd3a65c5559633c8',1,'object_create(char *name, Id id):&#160;object.c'],['../object_8c.html#a6c55f8c2541966f6dd3a65c5559633c8',1,'object_create(char *name, Id id):&#160;object.c']]],
  ['object_5fdestroy',['object_destroy',['../object_8h.html#a355e2f55e8467c2cfb2ef6bd5abbabfb',1,'object_destroy(Object *obj):&#160;object.c'],['../object_8c.html#a355e2f55e8467c2cfb2ef6bd5abbabfb',1,'object_destroy(Object *obj):&#160;object.c']]],
  ['object_5fget_5fdescription',['object_get_description',['../object_8h.html#a42dcce5b32474b5d2500329b97913c15',1,'object_get_description(Object *obj):&#160;object.c'],['../object_8c.html#a42dcce5b32474b5d2500329b97913c15',1,'object_get_description(Object *obj):&#160;object.c']]],
  ['object_5fget_5fid',['object_get_id',['../object_8h.html#ac9c3ace11b0440f373c67ccd3801398e',1,'object_get_id(Object *obj):&#160;object.c'],['../object_8c.html#ac9c3ace11b0440f373c67ccd3801398e',1,'object_get_id(Object *obj):&#160;object.c']]],
  ['object_5fget_5fname',['object_get_name',['../object_8h.html#ac6f2a9d9a4ed22600839724e8306f750',1,'object_get_name(Object *obj):&#160;object.c'],['../object_8c.html#ac6f2a9d9a4ed22600839724e8306f750',1,'object_get_name(Object *obj):&#160;object.c']]],
  ['object_5fset_5fdescription',['object_set_description',['../object_8h.html#a82b3e96992079f00a8553edd18777ef9',1,'object_set_description(Object *obj, char *descript):&#160;object.c'],['../object_8c.html#a28f4fc583f12c241619faa4456ef453d',1,'object_set_description(Object *obj, char *description):&#160;object.c']]],
  ['object_5fset_5fid',['object_set_id',['../object_8h.html#afcf71b4444a014a542f82c78bc9ee112',1,'object_set_id(Object *obj, Id id):&#160;object.c'],['../object_8c.html#afcf71b4444a014a542f82c78bc9ee112',1,'object_set_id(Object *obj, Id id):&#160;object.c']]],
  ['object_5fset_5fname',['object_set_name',['../object_8h.html#a1f468a3ddebae0cf31431705a824371a',1,'object_set_name(Object *obj, char *name):&#160;object.c'],['../object_8c.html#a1f468a3ddebae0cf31431705a824371a',1,'object_set_name(Object *obj, char *name):&#160;object.c']]]
];
