var searchData=
[
  ['name',['name',['../struct__Object.html#a5f13167436f75d12f48d3f152ce91d0a',1,'_Object::name()'],['../struct__Player.html#abd3fbad9568ff1e608654d58e71b8c58',1,'_Player::name()'],['../struct__Space.html#a4e8775f2ba9ae19392f9942dbb5f5ec0',1,'_Space::name()']]]
];
