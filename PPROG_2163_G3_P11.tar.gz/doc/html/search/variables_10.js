var searchData=
[
  ['width',['width',['../struct__Area.html#aa2f753fc3d254821603ac4512db814f1',1,'_Area']]]
];
