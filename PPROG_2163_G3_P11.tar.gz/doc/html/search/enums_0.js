var searchData=
[
  ['bool',['BOOL',['../types_8h.html#a3e5b8192e7d9ffaf3542f1210aec18dd',1,'types.h']]]
];
