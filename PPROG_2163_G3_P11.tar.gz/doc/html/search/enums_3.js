var searchData=
[
  ['linkstatus',['LinkStatus',['../types_8h.html#aa60f669816b146d6373c62d9625e52ad',1,'types.h']]]
];
