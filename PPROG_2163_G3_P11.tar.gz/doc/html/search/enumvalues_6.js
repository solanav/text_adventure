var searchData=
[
  ['ok',['OK',['../types_8h.html#a32c27cc471df37f4fc818d65de0a56c4a2bc49ec37d6a5715dd23e85f1ff5bb59',1,'types.h']]],
  ['open',['OPEN',['../types_8h.html#aa60f669816b146d6373c62d9625e52ada0e0143636c29971736eab47415868eae',1,'types.h']]]
];
