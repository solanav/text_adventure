var searchData=
[
  ['object',['Object',['../object_8h.html#a7f8bbcda919b65ce67f92fba08e0212f',1,'object.h']]],
  ['object_2ec',['object.c',['../object_8c.html',1,'']]],
  ['object_2eh',['object.h',['../object_8h.html',1,'']]],
  ['object_5fcreate',['object_create',['../object_8h.html#a6c55f8c2541966f6dd3a65c5559633c8',1,'object_create(char *name, Id id):&#160;object.c'],['../object_8c.html#a6c55f8c2541966f6dd3a65c5559633c8',1,'object_create(char *name, Id id):&#160;object.c']]],
  ['object_5fdestroy',['object_destroy',['../object_8h.html#a355e2f55e8467c2cfb2ef6bd5abbabfb',1,'object_destroy(Object *obj):&#160;object.c'],['../object_8c.html#a355e2f55e8467c2cfb2ef6bd5abbabfb',1,'object_destroy(Object *obj):&#160;object.c']]],
  ['object_5fget_5fdescription',['object_get_description',['../object_8h.html#a42dcce5b32474b5d2500329b97913c15',1,'object_get_description(Object *obj):&#160;object.c'],['../object_8c.html#a42dcce5b32474b5d2500329b97913c15',1,'object_get_description(Object *obj):&#160;object.c']]],
  ['object_5fget_5fid',['object_get_id',['../object_8h.html#ac9c3ace11b0440f373c67ccd3801398e',1,'object_get_id(Object *obj):&#160;object.c'],['../object_8c.html#ac9c3ace11b0440f373c67ccd3801398e',1,'object_get_id(Object *obj):&#160;object.c']]],
  ['object_5fget_5fname',['object_get_name',['../object_8h.html#ac6f2a9d9a4ed22600839724e8306f750',1,'object_get_name(Object *obj):&#160;object.c'],['../object_8c.html#ac6f2a9d9a4ed22600839724e8306f750',1,'object_get_name(Object *obj):&#160;object.c']]],
  ['object_5fset_5fdescription',['object_set_description',['../object_8h.html#a82b3e96992079f00a8553edd18777ef9',1,'object_set_description(Object *obj, char *descript):&#160;object.c'],['../object_8c.html#a28f4fc583f12c241619faa4456ef453d',1,'object_set_description(Object *obj, char *description):&#160;object.c']]],
  ['object_5fset_5fid',['object_set_id',['../object_8h.html#afcf71b4444a014a542f82c78bc9ee112',1,'object_set_id(Object *obj, Id id):&#160;object.c'],['../object_8c.html#afcf71b4444a014a542f82c78bc9ee112',1,'object_set_id(Object *obj, Id id):&#160;object.c']]],
  ['object_5fset_5fname',['object_set_name',['../object_8h.html#a1f468a3ddebae0cf31431705a824371a',1,'object_set_name(Object *obj, char *name):&#160;object.c'],['../object_8c.html#a1f468a3ddebae0cf31431705a824371a',1,'object_set_name(Object *obj, char *name):&#160;object.c']]],
  ['object_5ftest_2ec',['object_test.c',['../object__test_8c.html',1,'']]],
  ['object_5ftest_2eh',['object_test.h',['../object__test_8h.html',1,'']]],
  ['objects',['objects',['../struct__Game.html#ad45bf5645a26e546d0060a2e61f9cf81',1,'_Game::objects()'],['../struct__Space.html#a661ed8b0fc8085b6db70188aa5085625',1,'_Space::objects()']]],
  ['ok',['OK',['../types_8h.html#a32c27cc471df37f4fc818d65de0a56c4a2bc49ec37d6a5715dd23e85f1ff5bb59',1,'types.h']]],
  ['open',['OPEN',['../types_8h.html#aa60f669816b146d6373c62d9625e52ada0e0143636c29971736eab47415868eae',1,'types.h']]]
];
