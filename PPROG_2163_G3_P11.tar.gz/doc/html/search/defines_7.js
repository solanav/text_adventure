var searchData=
[
  ['print_5fpassed_5fpercentage',['PRINT_PASSED_PERCENTAGE',['../test_8h.html#a4a5b9a0026e80b1cfbfbbc3fa700ed31',1,'test.h']]],
  ['print_5ftest_5fresult',['PRINT_TEST_RESULT',['../test_8h.html#a6c00863b1d44e38839b1f4b49d04f403',1,'test.h']]],
  ['prompt',['PROMPT',['../screen_8c.html#accdbea14ea06c15e271784368bd993e8',1,'screen.c']]]
];
