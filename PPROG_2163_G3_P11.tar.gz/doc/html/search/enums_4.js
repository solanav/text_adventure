var searchData=
[
  ['status',['STATUS',['../types_8h.html#a32c27cc471df37f4fc818d65de0a56c4',1,'types.h']]]
];
