var searchData=
[
  ['reset',['RESET',['../test_8h.html#ab702106cf3b3e96750b6845ded4e0299',1,'test.h']]],
  ['result',['result',['../struct__Die.html#a93f9aa650af74c81ab2377ceb7324250',1,'_Die']]],
  ['roll',['ROLL',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50ca2eeb9fef8a6a516fa6437a44a6efbd52',1,'command.h']]],
  ['rows',['ROWS',['../screen_8c.html#a3cfd3aa62338d12609f6d65bce97e9cd',1,'screen.c']]]
];
