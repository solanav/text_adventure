var searchData=
[
  ['game_5fcallback_5ffn_5flist',['game_callback_fn_list',['../game_8c.html#a736ddaf27abb68c75a635760497a3f5e',1,'game.c']]],
  ['gdesc',['gdesc',['../struct__Space.html#a0a71c4c0a4a1698f7d860ba5b80beb7f',1,'_Space']]]
];
