var searchData=
[
  ['die_5fdie_5fdie',['die_die_die',['../die_8h.html#a94ea40d2a3508e2d6aac560582e9e9bc',1,'die_die_die(Die *):&#160;die.c'],['../die_8c.html#aa8e971f9b27132eda0d1e8177adc7ed5',1,'die_die_die(Die *die):&#160;die.c']]],
  ['die_5fget_5flast_5froll',['die_get_last_roll',['../die_8h.html#a8bf4da5fb5440c903b605e54ceae97e5',1,'die_get_last_roll(Die *):&#160;die.c'],['../die_8c.html#a734148bcd7a5fc018966fa3b7909ac4a',1,'die_get_last_roll(Die *die):&#160;die.c']]],
  ['die_5fini',['die_ini',['../die_8h.html#a58ac2859cec9338bd57d2cbf142f565f',1,'die_ini(Id):&#160;die.c'],['../die_8c.html#ad5714ba396ffc8c964b7be67240508b2',1,'die_ini(Id id):&#160;die.c']]],
  ['die_5fprint',['die_print',['../die_8h.html#ac5fb013351c7196f7ace1ac1043771fc',1,'die_print(FILE *, Die *):&#160;die.c'],['../die_8c.html#a4ba0de5e507530e14302ac5096d7df56',1,'die_print(FILE *f, Die *die):&#160;die.c']]],
  ['die_5froll',['die_roll',['../die_8h.html#a8b747943478f695a940e267d69baae7b',1,'die_roll(Die *):&#160;die.c'],['../die_8c.html#afafc56aafeb40dbf889c421cace3d919',1,'die_roll(Die *die):&#160;die.c']]]
];
