/**
 * @brief It declares the tests for the player module
 *
 * @file player_test.h
 * @author Pablo Sánchez Redondo
 * @copyright GNU Public License
 */

#ifndef PLAYER_TEST_H
#define PLAYER_TEST_H

void test1_player_create();
void test1_player_set_name();
void test2_player_set_name();
void test1_player_set_LocId();
void test2_player_set_LocId();
void test1_player_set_ObjId();
void test2_player_set_ObjId();
void test1_player_set_id();
void test2_player_set_id();
void test1_player_get_name();
void test1_player_get_LocId();
void test1_player_get_ObjId();
void test1_player_get_id();
void test1_player_remove_object_id();
void test2_player_remove_object_id();

#endif
